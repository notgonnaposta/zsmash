using UnityEngine;

public class Quit : MonoBehaviour
{
    public void quitgame()
    {
        Application.Quit();
        Debug.Log("game quitted lmao");
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
