
using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;

public class Damage : MonoBehaviour
{
    public float health = 100f;
}